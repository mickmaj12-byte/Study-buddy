// Vercel Node.js function. Keep OPENAI_API_KEY in Vercel environment variables only.
const allowedModes = new Set(["explain", "summarize", "quiz"]);
const MAX_INPUT_LENGTH = 12000;

module.exports = async function handler(req, res) {
  res.setHeader("Cache-Control", "no-store");
  res.setHeader("X-Content-Type-Options", "nosniff");

  if (req.method !== "POST") {
    res.setHeader("Allow", "POST");
    return res.status(405).json({error: "Use a POST request."});
  }

  let body = req.body;
  if (typeof body === "string") {
    try { body = JSON.parse(body); }
    catch { return res.status(400).json({error: "Please send valid JSON."}); }
  }
  if (!body || typeof body !== "object") {
    return res.status(400).json({error: "Please send valid JSON."});
  }

  const {mode, input, subject = "General", style = "bullet points", count = 5, level = "Medium"} = body;
  if (!allowedModes.has(mode)) return res.status(400).json({error: "Choose a valid study tool."});
  if (typeof input !== "string" || !input.trim()) return res.status(400).json({error: "Add a question or some study material first."});
  if (input.length > MAX_INPUT_LENGTH) return res.status(413).json({error: "Please keep your input under 12,000 characters."});

  const apiKey = process.env.OPENAI_API_KEY;
  if (!apiKey) return res.status(503).json({error: "AI isn't configured yet. Add OPENAI_API_KEY to your hosting provider's environment variables."});

  let instructions;
  let prompt;
  if (mode === "explain") {
    instructions = "You are Study Buddy, a friendly, patient tutor for school students. Explain concepts accurately in age-appropriate language. Teach step by step, define tricky words, use a simple example, and check understanding with one short follow-up question when helpful. Help the student learn rather than merely giving unexplained answers. Never claim certainty when uncertain. Format with short headings and numbered steps when useful.";
    prompt = `Subject: ${String(subject).slice(0, 80)}\nStudent question:\n${input}`;
  } else if (mode === "summarize") {
    instructions = "You are Study Buddy, a careful study-notes assistant. Summarize only the supplied material; do not invent facts. Make it clear and useful for a school student. If the source appears incomplete or contains a possible error, say so briefly.";
    prompt = `Summarize these notes as ${String(style).slice(0, 80)}. Keep the main facts and important vocabulary.\n\nNOTES:\n${input}`;
  } else {
    instructions = "You are Study Buddy, a quiz writer. Create the requested number of practice questions from the supplied topic or notes. Use a mix of multiple choice and short answer where suitable. Put the answer key at the end with brief explanations. Keep the questions grounded in the supplied material and clearly number them.";
    const safeCount = [5, 8, 10].includes(Number(count)) ? Number(count) : 5;
    const safeLevel = ["Easy", "Medium", "Challenging"].includes(level) ? level : "Medium";
    prompt = `Create ${safeCount} ${safeLevel.toLowerCase()} practice questions using this material. Put answers in a separate answer key at the end.\n\nMATERIAL:\n${input}`;
  }

  try {
    const upstream = await fetch("https://api.openai.com/v1/responses", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${apiKey}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        model: process.env.OPENAI_MODEL || "gpt-4.1-mini",
        instructions,
        input: prompt,
        max_output_tokens: 1400
      })
    });
    const data = await upstream.json().catch(() => ({}));
    if (!upstream.ok) {
      console.error("OpenAI request failed:", upstream.status);
      if (upstream.status === 401) return res.status(502).json({error: "The server's AI key was rejected. Check the OPENAI_API_KEY setting."});
      if (upstream.status === 429) return res.status(429).json({error: "The AI service is busy or the API quota is reached. Check your API billing and try again."});
      return res.status(502).json({error: "The AI service couldn't complete that request. Please try again."});
    }
    const answer = (data.output || [])
      .flatMap(item => item.content || [])
      .filter(item => item.type === "output_text")
      .map(item => item.text)
      .join("\n")
      .trim();
    if (!answer) return res.status(502).json({error: "The AI returned an empty answer. Please try again."});
    return res.status(200).json({answer});
  } catch (error) {
    console.error("AI endpoint error:", error && error.message);
    return res.status(502).json({error: "Couldn't reach the AI service. Check your connection and try again."});
  }
};
